// testVolume.cpp
#include "TestCounters.h"  // Include the header

// Define the counters (remove 'static')
int passed = 0;
int failed = 0;
